This is a project made as a university assignment, which consisted on creating a memory game using HTML, CSS, JavaScript and JQuery.
